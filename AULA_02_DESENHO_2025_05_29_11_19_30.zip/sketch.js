function setup() {
createCanvas(400,400)
}

function draw() {
  background(255,69,0);
  
  fill(0,0,200)
stroke(139,0,0)
strokeWeight(4)
  circle(200,200,250);
fill(255,250,250)
  stroke(160,82,45)
  circle(140,172,45)
circle(250,170,45);
  fill(144,238,144)
  stroke(216,191.216)
  strokeWeight(6)
  line(160,140,100,150);
  fill(255,10,255)
  line(300,140,230,136);
  circle(mouseX,mouseY,40)
  fill(131,111,255)
  triangle(200,180,170,220,220,220);
  line(150,270,250,235);
}
